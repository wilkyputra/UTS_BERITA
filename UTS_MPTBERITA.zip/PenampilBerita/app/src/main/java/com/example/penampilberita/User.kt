package com.example.penampilberita

data class User (
    val id:String, val judul: String, val waktu: String, val penulis: String, val isi: String
)